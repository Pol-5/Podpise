package com.example.podpise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class activity_open_sign extends AppCompatActivity {

    private String mas[];
    private int i=0;
    private TextView text_1,text_2,text_3,text_4,text_5,text_6,text_7,text_20,text_21;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_sign);

        text_1=findViewById(R.id.textView9);
        text_2=findViewById(R.id.textView10);
        text_3=findViewById(R.id.textView11);
        text_4=findViewById(R.id.textView12);
        text_5=findViewById(R.id.textView13);
        text_6=findViewById(R.id.textView14);
        text_7=findViewById(R.id.textView15);
        text_20=findViewById(R.id.textView20);
        text_21=findViewById(R.id.textView21);

        mas=new String[7];
        try {
            FileInputStream file_input=openFileInput("Sign.txt");
            InputStreamReader reader=new InputStreamReader(file_input);
            BufferedReader buffer=new BufferedReader(reader);
            StringBuffer str_buffer=new StringBuffer();
            String lines;
            while((lines=buffer.readLine())!=null)
            {
                str_buffer.append(lines+"\n");
                mas[i]=lines;
                i++;
            }
            if(text_6.equals("Преподаватель"))
            {
                text_20.setText(R.string.Job_title);
                text_21.setText(R.string.Number_certificate);
            }
            else
            {
                text_20.setText(R.string.Number_group);
                text_21.setText(R.string.Number_record_book);
            }
            text_1.setText(mas[0]);
            text_2.setText(mas[1]);
            text_3.setText(mas[2]);
            text_4.setText(mas[3]);
            text_5.setText(mas[4]);
            text_6.setText(mas[5]);
            text_7.setText(mas[6]);
        }
        catch (
                FileNotFoundException e) {throw new RuntimeException(e);}
        catch (
                IOException e) {throw new RuntimeException(e);}
    }
}