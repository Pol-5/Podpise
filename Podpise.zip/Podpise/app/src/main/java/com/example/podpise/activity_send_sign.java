package com.example.podpise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activity_send_sign extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_sign);
    }
}