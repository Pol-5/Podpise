package com.example.podpise;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

import android.content.Context;
import android.content.ReceiverCallNotAllowedException;
import android.hardware.Camera;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Create_sign extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private EditText text_1,text_2,text_3,text_4,text_5;
    private Spinner spinner;
    private String text,key;
    private char[] mas;
    private boolean a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_sign);

        text_1=findViewById(R.id.editTextText);
        text_2=findViewById(R.id.editTextText5);
        text_3=findViewById(R.id.editTextText2);
        text_4=findViewById(R.id.editTextText3);
        text_5=findViewById(R.id.editTextText4);

        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.Role, android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }




    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
    {
        text=adapterView.getItemAtPosition(i).toString();
        String text_3="Преподаватель";
        if(text.equals(text_3))
        {
            text_1.setHint(R.string.Job_title);
            text_2.setHint(R.string.Number_certificate);
        }
        else
        {
            text_1.setHint(R.string.Number_group);
            text_2.setHint(R.string.Number_record_book);
        }
        Toast.makeText(adapterView.getContext(),text,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


    public void CreateKey(View v) {
        mas=new char[10];
        Random rand=new Random();
        String alpha="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for(int i=0;i<mas.length;i++)
        {
            mas[i] = alpha.charAt(rand.nextInt(alpha.length()));
            key+=mas[i];
        }


        try {
            FileOutputStream file_output = openFileOutput("Sign.txt", MODE_PRIVATE);
            file_output.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        a = true;
        String[] data = {text_3.getText().toString(), text_4.getText().toString(), text_5.getText().toString(), text_1.getText().toString(), text_2.getText().toString(),text};

        try {
            FileInputStream file_input=openFileInput("Sign.txt");
InputStreamReader reader=new InputStreamReader(file_input);
BufferedReader buffer=new BufferedReader(reader);
StringBuffer str_buffer=new StringBuffer();
String lines;

while((lines=buffer.readLine())!=null)
{
str_buffer.append(lines+"\n");
if(data[4].equals(lines))
{   Toast.makeText(Create_sign.this, "В базе данных есть уже человек с данным номером", Toast.LENGTH_SHORT).show();
    a = false;
    break;
}
    a=false;
}
if(a==false)
    Toast.makeText(Create_sign.this, "Вы уже сделали электронную подпись", Toast.LENGTH_SHORT).show();
        }
        catch (FileNotFoundException e) {throw new RuntimeException(e);}
        catch (IOException e) {throw new RuntimeException(e);}

        for (int i = 0; i < data.length; i++) {
            if (data[i].equals("")) {
                Toast.makeText(Create_sign.this, "Не все поля заполнены", Toast.LENGTH_SHORT).show();
                a = false;
                break;
            }
        }

        if (a == true) {
            try {
                FileOutputStream file_output = openFileOutput("Sign.txt", MODE_PRIVATE);
                file_output.write((data[0]+"\n").getBytes());
                file_output.write((data[1]+"\n").getBytes());
                file_output.write((data[2]+"\n").getBytes());
                file_output.write((data[3]+"\n").getBytes());
                file_output.write((data[4]+"\n").getBytes());
                file_output.write((text+"\n").getBytes());
                file_output.write((key+"\n").getBytes());
                file_output.close();
                text_1.setText("");
                text_2.setText("");
                text_3.setText("");
                text_4.setText("");
                text_5.setText("");
                Toast.makeText(Create_sign.this, "Сохранено", Toast.LENGTH_SHORT).show();
                a=false;
            }
            catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }


}